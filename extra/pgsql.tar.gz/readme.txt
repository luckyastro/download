sudo /usr/pgsql-17/bin/postgresql-17-setup initdb
